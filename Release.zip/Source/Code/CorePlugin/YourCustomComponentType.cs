﻿using System;
using System.Collections.Generic;
using System.Linq;

using Duality;

namespace Release
{
	public class YourCustomComponentType : Component
	{
		
	}
}
