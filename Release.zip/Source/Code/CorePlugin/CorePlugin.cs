﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Duality;

namespace Release
{
	/// <summary>
	/// Defines a Duality core plugin.
	/// </summary>
	public class ReleaseCorePlugin : CorePlugin
	{
		// Override methods here for global logic
	}
}
