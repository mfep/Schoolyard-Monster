﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Duality.Editor;

namespace Release.Editor
{
	/// <summary>
	/// Defines a Duality editor plugin.
	/// </summary>
    public class ReleaseEditorPlugin : EditorPlugin
	{
		public override string Id
		{
			get { return "ReleaseEditorPlugin"; }
		}
	}
}
